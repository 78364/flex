// ShopHub E-commerce JavaScript
class ShopHub {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('shophub-cart')) || [];
        this.products = this.generateSampleProducts();
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.initAnimations();
        this.loadTrendingProducts();
        this.updateCartUI();
        this.initBrandCarousel();
        this.setupScrollReveal();
    }

    setupEventListeners() {
        // Mobile menu toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mobileMenu = document.getElementById('mobileMenu');
        
        if (mobileMenuBtn && mobileMenu) {
            mobileMenuBtn.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
            });
        }

        // Cart functionality
        const cartBtn = document.getElementById('cartBtn');
        const cartSidebar = document.getElementById('cartSidebar');
        const cartOverlay = document.getElementById('cartOverlay');
        const closeCart = document.getElementById('closeCart');

        if (cartBtn) {
            cartBtn.addEventListener('click', () => this.toggleCart());
        }
        if (closeCart) {
            closeCart.addEventListener('click', () => this.closeCart());
        }
        if (cartOverlay) {
            cartOverlay.addEventListener('click', () => this.closeCart());
        }

        // Newsletter form
        const newsletterForm = document.getElementById('newsletterForm');
        if (newsletterForm) {
            newsletterForm.addEventListener('submit', (e) => this.handleNewsletter(e));
        }

        // Search functionality
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => this.handleSearch(e));
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch(e.target.value);
                }
            });
        }

        // Explore brands button
        const exploreBtn = document.getElementById('exploreBtn');
        if (exploreBtn) {
            exploreBtn.addEventListener('click', () => {
                document.querySelector('#brandCarousel').scrollIntoView({ 
                    behavior: 'smooth' 
                });
            });
        }

        // User button
        const userBtn = document.getElementById('userBtn');
        if (userBtn) {
            userBtn.addEventListener('click', () => {
                window.location.href = 'account.html';
            });
        }
    }

    initAnimations() {
        // Typed.js for hero text
        if (document.getElementById('typed-text')) {
            new Typed('#typed-text', {
                strings: ['Premium Brands', 'Quality Products', 'Amazing Deals', 'Your Style'],
                typeSpeed: 100,
                backSpeed: 50,
                backDelay: 2000,
                loop: true,
                showCursor: true,
                cursorChar: '|'
            });
        }

        // Hero text animation
        setTimeout(() => {
            const heroText = document.querySelector('.hero-text');
            if (heroText) {
                heroText.classList.add('animate');
            }
        }, 500);
    }

    initBrandCarousel() {
        const brandCarousel = document.getElementById('brandCarousel');
        if (brandCarousel) {
            new Splide('#brandCarousel', {
                type: 'loop',
                perPage: 5,
                perMove: 1,
                gap: '2rem',
                autoplay: true,
                interval: 3000,
                pauseOnHover: true,
                breakpoints: {
                    1024: { perPage: 4 },
                    768: { perPage: 3 },
                    480: { perPage: 2 }
                }
            }).mount();
        }
    }

    setupScrollReveal() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.scroll-reveal').forEach(el => {
            observer.observe(el);
        });
    }

    generateSampleProducts() {
        return [
            {
                id: 1,
                name: "iPhone 15 Pro Max",
                brand: "Apple",
                category: "electronics",
                price: 1199,
                originalPrice: 1299,
                image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=300&h=300&fit=crop",
                rating: 4.8,
                reviews: 1250,
                description: "The most advanced iPhone with titanium design and A17 Pro chip."
            },
            {
                id: 2,
                name: "Nike Air Max 270",
                brand: "Nike",
                category: "sports",
                price: 150,
                originalPrice: 180,
                image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&h=300&fit=crop",
                rating: 4.6,
                reviews: 890,
                description: "Comfortable running shoes with Max Air cushioning technology."
            },
            {
                id: 3,
                name: "Zara Leather Jacket",
                brand: "Zara",
                category: "fashion",
                price: 199,
                originalPrice: 249,
                image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=300&h=300&fit=crop",
                rating: 4.4,
                reviews: 456,
                description: "Stylish genuine leather jacket with modern fit and premium quality."
            },
            {
                id: 4,
                name: "IKEA EKTORP Sofa",
                brand: "IKEA",
                category: "home",
                price: 599,
                originalPrice: 699,
                image: "https://images.unsplash.com/photo-1550581190-9c1c48d21d6c?w=300&h=300&fit=crop",
                rating: 4.7,
                reviews: 234,
                description: "Comfortable 3-seat sofa with removable covers for easy cleaning."
            },
            {
                id: 5,
                name: "Sephora Foundation Set",
                brand: "Sephora",
                category: "beauty",
                price: 45,
                originalPrice: 55,
                image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=300&h=300&fit=crop",
                rating: 4.5,
                reviews: 678,
                description: "Complete foundation set with multiple shades and professional tools."
            },
            {
                id: 6,
                name: "MacBook Pro 14\"",
                brand: "Apple",
                category: "electronics",
                price: 1999,
                originalPrice: 2199,
                image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300&h=300&fit=crop",
                rating: 4.9,
                reviews: 567,
                description: "Powerful laptop with M3 Pro chip and stunning Liquid Retina XDR display."
            },
            {
                id: 7,
                name: "Adidas Ultraboost 22",
                brand: "Adidas",
                category: "sports",
                price: 180,
                originalPrice: 220,
                image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=300&h=300&fit=crop",
                rating: 4.7,
                reviews: 445,
                description: "Premium running shoes with Boost cushioning and Continental outsole."
            },
            {
                id: 8,
                name: "H&M Denim Jacket",
                brand: "H&M",
                category: "fashion",
                price: 59,
                originalPrice: 79,
                image: "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=300&h=300&fit=crop",
                rating: 4.3,
                reviews: 334,
                description: "Classic denim jacket with modern fit and sustainable materials."
            },
            {
                id: 9,
                name: "Bosch Drill Set",
                brand: "Bosch",
                category: "home",
                price: 129,
                originalPrice: 159,
                image: "https://images.unsplash.com/photo-1581092921356-143de2397a69?w=300&h=300&fit=crop",
                rating: 4.6,
                reviews: 223,
                description: "Professional cordless drill set with multiple accessories."
            },
            {
                id: 10,
                name: "Fenty Beauty Lipstick",
                brand: "Fenty Beauty",
                category: "beauty",
                price: 25,
                originalPrice: 30,
                image: "https://images.unsplash.com/photo-1586495777744-4413f21062fa?w=300&h=300&fit=crop",
                rating: 4.8,
                reviews: 789,
                description: "Long-lasting matte lipstick in versatile shades for all skin tones."
            },
            {
                id: 11,
                name: "Sony WH-1000XM5",
                brand: "Sony",
                category: "electronics",
                price: 399,
                originalPrice: 449,
                image: "https://images.unsplash.com/photo-1583394838336-acd977736f90?w=300&h=300&fit=crop",
                rating: 4.8,
                reviews: 1123,
                description: "Industry-leading noise canceling headphones with exceptional sound quality."
            },
            {
                id: 12,
                name: "Lululemon Yoga Mat",
                brand: "Lululemon",
                category: "sports",
                price: 78,
                originalPrice: 98,
                image: "https://images.unsplash.com/photo-1592432678016-e910b452f9a2?w=300&h=300&fit=crop",
                rating: 4.9,
                reviews: 456,
                description: "Premium reversible yoga mat with superior grip and cushioning."
            },
            {
                id: 13,
                name: "Uniqlo Cashmere Sweater",
                brand: "Uniqlo",
                category: "fashion",
                price: 89,
                originalPrice: 119,
                image: "https://images.unsplash.com/photo-1616258417208-613612351234?w=300&h=300&fit=crop",
                rating: 4.5,
                reviews: 267,
                description: "Luxurious cashmere sweater with timeless design and superior comfort."
            },
            {
                id: 14,
                name: "Philips Air Fryer",
                brand: "Philips",
                category: "home",
                price: 199,
                originalPrice: 249,
                image: "https://images.unsplash.com/photo-1585515320310-259814833e62?w=300&h=300&fit=crop",
                rating: 4.7,
                reviews: 889,
                description: "Healthy cooking with Rapid Air Technology for crispy results."
            },
            {
                id: 15,
                name: "Glossier Skincare Set",
                brand: "Glossier",
                category: "beauty",
                price: 65,
                originalPrice: 85,
                image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=300&h=300&fit=crop",
                rating: 4.6,
                reviews: 334,
                description: "Complete skincare routine with gentle, effective products."
            },
            {
                id: 16,
                name: "Samsung Galaxy Watch 6",
                brand: "Samsung",
                category: "electronics",
                price: 329,
                originalPrice: 379,
                image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=300&h=300&fit=crop",
                rating: 4.5,
                reviews: 445,
                description: "Advanced smartwatch with health monitoring and GPS tracking."
            },
            {
                id: 17,
                name: "Patagonia Down Jacket",
                brand: "Patagonia",
                category: "sports",
                price: 229,
                originalPrice: 279,
                image: "https://images.unsplash.com/photo-1539533018447-63fcce267535?w=300&h=300&fit=crop",
                rating: 4.8,
                reviews: 567,
                description: "Sustainable down jacket perfect for outdoor adventures."
            },
            {
                id: 18,
                name: "Levi's 501 Jeans",
                brand: "Levi's",
                category: "fashion",
                price: 98,
                originalPrice: 118,
                image: "https://images.unsplash.com/photo-1604176354204-9268737828e4?w=300&h=300&fit=crop",
                rating: 4.4,
                reviews: 1234,
                description: "Classic straight fit jeans with iconic style and durability."
            },
            {
                id: 19,
                name: "Dyson V15 Vacuum",
                brand: "Dyson",
                category: "home",
                price: 749,
                originalPrice: 849,
                image: "https://images.unsplash.com/photo-1556139930-c23fa4a4f934?w=300&h=300&fit=crop",
                rating: 4.9,
                reviews: 334,
                description: "Powerful cordless vacuum with laser detection technology."
            },
            {
                id: 20,
                name: "Charlotte Tilbury Palette",
                brand: "Charlotte Tilbury",
                category: "beauty",
                price: 75,
                originalPrice: 95,
                image: "https://images.unsplash.com/photo-1631214540242-3cd5c5c8e5a1?w=300&h=300&fit=crop",
                rating: 4.7,
                reviews: 456,
                description: "Luxury eyeshadow palette with versatile, blendable shades."
            }
        ];
    }

    loadTrendingProducts() {
        const container = document.getElementById('trendingProducts');
        if (!container) return;

        // Get trending products (highest rated)
        const trending = this.products
            .sort((a, b) => b.rating - a.rating)
            .slice(0, 8);

        container.innerHTML = trending.map(product => this.createProductCard(product)).join('');
        
        // Add event listeners to product cards
        this.attachProductEventListeners();
    }

    createProductCard(product) {
        const discount = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100);
        const stars = this.generateStars(product.rating);

        return `
            <div class="product-card card-hover" data-product-id="${product.id}">
                <div class="relative">
                    <img src="${product.image}" alt="${product.name}" 
                         class="w-full h-64 object-cover">
                    ${discount > 0 ? `<div class="price-badge absolute top-4 left-4 px-2 py-1 rounded-full text-sm">-${discount}%</div>` : ''}
                    <button class="absolute top-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-50 transition-colors add-to-wishlist">
                        <i class="far fa-heart text-secondary-color"></i>
                    </button>
                </div>
                
                <div class="p-6">
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm text-secondary-color uppercase tracking-wide">${product.brand}</span>
                        <div class="flex items-center">
                            ${stars}
                            <span class="text-sm text-secondary-color ml-1">(${product.reviews})</span>
                        </div>
                    </div>
                    
                    <h3 class="font-semibold text-lg mb-2 line-clamp-2">${product.name}</h3>
                    <p class="text-secondary-color text-sm mb-4 line-clamp-2">${product.description}</p>
                    
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <span class="text-2xl font-bold text-primary-color">$${product.price}</span>
                            ${product.originalPrice > product.price ? `<span class="text-secondary-color line-through">$${product.originalPrice}</span>` : ''}
                        </div>
                        <button class="btn-primary px-4 py-2 rounded-full text-sm font-semibold add-to-cart">
                            Add to Cart
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        let stars = '';

        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star text-warning-color text-sm"></i>';
        }

        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt text-warning-color text-sm"></i>';
        }

        const emptyStars = 5 - Math.ceil(rating);
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star text-warning-color text-sm"></i>';
        }

        return stars;
    }

    attachProductEventListeners() {
        // Add to cart buttons
        document.querySelectorAll('.add-to-cart').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const productCard = e.target.closest('.product-card');
                const productId = parseInt(productCard.dataset.productId);
                this.addToCart(productId);
            });
        });

        // Add to wishlist buttons
        document.querySelectorAll('.add-to-wishlist').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const icon = e.target.querySelector('i');
                icon.classList.toggle('far');
                icon.classList.toggle('fas');
                icon.classList.toggle('text-accent-color');
                
                this.showNotification('Added to wishlist!', 'success');
            });
        });
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) return;

        const existingItem = this.cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            this.cart.push({
                ...product,
                quantity: 1
            });
        }

        this.saveCart();
        this.updateCartUI();
        this.showNotification('Added to cart!', 'success');
        
        // Animate cart icon
        const cartBtn = document.getElementById('cartBtn');
        if (cartBtn) {
            cartBtn.classList.add('animate-bounce');
            setTimeout(() => cartBtn.classList.remove('animate-bounce'), 1000);
        }
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
        this.updateCartUI();
        this.showNotification('Removed from cart', 'info');
    }

    updateCartQuantity(productId, quantity) {
        const item = this.cart.find(item => item.id === productId);
        if (item) {
            if (quantity <= 0) {
                this.removeFromCart(productId);
            } else {
                item.quantity = quantity;
                this.saveCart();
                this.updateCartUI();
            }
        }
    }

    updateCartUI() {
        const cartCount = document.getElementById('cartCount');
        const cartItems = document.getElementById('cartItems');
        const cartTotal = document.getElementById('cartTotal');
        const emptyCart = document.getElementById('emptyCart');

        const totalItems = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        const totalPrice = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

        if (cartCount) {
            cartCount.textContent = totalItems;
            cartCount.style.display = totalItems > 0 ? 'flex' : 'none';
        }

        if (cartTotal) {
            cartTotal.textContent = `$${totalPrice.toFixed(2)}`;
        }

        if (cartItems && emptyCart) {
            if (this.cart.length === 0) {
                cartItems.style.display = 'none';
                emptyCart.style.display = 'block';
            } else {
                cartItems.style.display = 'block';
                emptyCart.style.display = 'none';
                cartItems.innerHTML = this.cart.map(item => this.createCartItem(item)).join('');
                
                // Attach cart item event listeners
                this.attachCartItemEventListeners();
            }
        }
    }

    createCartItem(item) {
        return `
            <div class="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                <img src="${item.image}" alt="${item.name}" class="w-16 h-16 object-cover rounded-lg">
                <div class="flex-1">
                    <h4 class="font-semibold text-sm">${item.name}</h4>
                    <p class="text-secondary-color text-sm">$${item.price}</p>
                    <div class="flex items-center space-x-2 mt-2">
                        <button class="w-8 h-8 bg-white border rounded-full flex items-center justify-center hover:bg-gray-100 update-quantity" data-id="${item.id}" data-action="decrease">
                            <i class="fas fa-minus text-xs"></i>
                        </button>
                        <span class="w-8 text-center">${item.quantity}</span>
                        <button class="w-8 h-8 bg-white border rounded-full flex items-center justify-center hover:bg-gray-100 update-quantity" data-id="${item.id}" data-action="increase">
                            <i class="fas fa-plus text-xs"></i>
                        </button>
                    </div>
                </div>
                <button class="text-secondary-color hover:text-accent-color remove-item" data-id="${item.id}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
    }

    attachCartItemEventListeners() {
        // Update quantity buttons
        document.querySelectorAll('.update-quantity').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = parseInt(e.target.dataset.id);
                const action = e.target.dataset.action;
                const item = this.cart.find(item => item.id === productId);
                
                if (item) {
                    const newQuantity = action === 'increase' ? item.quantity + 1 : item.quantity - 1;
                    this.updateCartQuantity(productId, newQuantity);
                }
            });
        });

        // Remove item buttons
        document.querySelectorAll('.remove-item').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const productId = parseInt(e.target.dataset.id);
                this.removeFromCart(productId);
            });
        });
    }

    toggleCart() {
        const cartSidebar = document.getElementById('cartSidebar');
        const cartOverlay = document.getElementById('cartOverlay');
        
        if (cartSidebar && cartOverlay) {
            const isOpen = !cartSidebar.classList.contains('translate-x-full');
            
            if (isOpen) {
                this.closeCart();
            } else {
                cartSidebar.classList.remove('translate-x-full');
                cartOverlay.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }
        }
    }

    closeCart() {
        const cartSidebar = document.getElementById('cartSidebar');
        const cartOverlay = document.getElementById('cartOverlay');
        
        if (cartSidebar && cartOverlay) {
            cartSidebar.classList.add('translate-x-full');
            cartOverlay.classList.add('hidden');
            document.body.style.overflow = '';
        }
    }

    handleSearch(e) {
        const query = e.target.value.trim();
        if (query.length > 2) {
            // Show search suggestions (implement if needed)
            console.log('Searching for:', query);
        }
    }

    performSearch(query) {
        if (query.trim()) {
            window.location.href = `products.html?search=${encodeURIComponent(query)}`;
        }
    }

    handleNewsletter(e) {
        e.preventDefault();
        const email = document.getElementById('email').value;
        
        // Simulate newsletter subscription
        this.showNotification('Thank you for subscribing!', 'success');
        document.getElementById('email').value = '';
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `fixed top-20 right-4 z-50 px-6 py-3 rounded-lg shadow-lg transform translate-x-full transition-transform duration-300 ${
            type === 'success' ? 'bg-green-500 text-white' :
            type === 'error' ? 'bg-red-500 text-white' :
            'bg-blue-500 text-white'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.classList.remove('translate-x-full');
        }, 100);
        
        // Animate out and remove
        setTimeout(() => {
            notification.classList.add('translate-x-full');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    saveCart() {
        localStorage.setItem('shophub-cart', JSON.stringify(this.cart));
    }

    // Utility methods
    formatPrice(price) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(price);
    }

    getProductById(id) {
        return this.products.find(p => p.id === id);
    }

    getProductsByCategory(category) {
        return this.products.filter(p => p.category === category);
    }

    getProductsByBrand(brand) {
        return this.products.filter(p => p.brand === brand);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.shopHub = new ShopHub();
});

// Export for use in other pages
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ShopHub;
}