# ShopHub - Modern Multi-Brand E-commerce Platform

A feature-rich, user-friendly e-commerce website built with HTML, CSS, JavaScript, Node.js, and MongoDB. ShopHub offers a seamless shopping experience across multiple brands with advanced features like smart filtering, persistent shopping cart, and responsive design.

## 🌟 Features

### Frontend Features
- **Modern Responsive Design** - Works perfectly on desktop, tablet, and mobile
- **Multi-Brand Shopping** - Browse products from Nike, Apple, Zara, IKEA, Sephora, and more
- **Advanced Product Filtering** - Filter by category, brand, price range, and rating
- **Smart Search** - Real-time search with autocomplete suggestions
- **Shopping Cart** - Persistent cart with quantity management and discount codes
- **User Accounts** - Complete account management with order history and wishlist
- **Smooth Animations** - Powered by Anime.js for delightful user interactions
- **Product Carousels** - Beautiful product showcases using Splide.js

### Backend Features
- **RESTful API** - Clean, well-documented API endpoints
- **User Authentication** - Secure registration and login with JWT tokens
- **Database Integration** - MongoDB with Mongoose ODM
- **Order Management** - Complete order processing and tracking
- **Wishlist System** - Save favorite products for later
- **Discount Codes** - Built-in promotional code system

## 🛠 Technology Stack

### Frontend
- **HTML5** - Semantic markup and accessibility
- **CSS3** - Flexbox, Grid, custom properties, and animations
- **JavaScript ES6+** - Modern syntax, modules, async/await
- **Tailwind CSS** - Utility-first CSS framework
- **Animation Libraries** - Anime.js, Typed.js, Splide.js

### Backend
- **Node.js** - Server runtime
- **Express.js** - Web framework and API
- **MongoDB** - NoSQL database
- **Mongoose** - MongoDB object modeling
- **JWT** - Authentication tokens
- **Bcrypt** - Password hashing

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (v4.0 or higher)
- npm or yarn package manager

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd shophub-ecommerce
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```env
   MONGODB_URI=mongodb://localhost:27017/shophub
   JWT_SECRET=your-super-secret-jwt-key
   PORT=3000
   ```

4. **Start MongoDB**
   Make sure MongoDB is running on your system:
   ```bash
   # For local MongoDB
   mongod
   
   # Or use MongoDB Atlas (cloud)
   # Update MONGODB_URI in .env file
   ```

5. **Run the application**
   ```bash
   # Development mode with auto-reload
   npm run dev
   
   # Or production mode
   npm start
   ```

6. **Open your browser**
   Navigate to `http://localhost:3000`

## 📁 Project Structure

```
shophub-ecommerce/
├── index.html              # Landing page
├── products.html           # Product catalog
├── cart.html              # Shopping cart
├── account.html           # User account
├── main.js                # Main JavaScript functionality
├── server.js              # Node.js server
├── package.json           # Dependencies
├── design.md              # Design system documentation
├── interaction.md         # Interaction design specs
├── outline.md             # Project outline
├── hero-banner.png        # Hero section image
├── product-showcase.png   # Product showcase image
└── README.md              # This file
```

## 🎯 Usage Guide

### For Shoppers
1. **Browse Products** - Use the navigation or search to find products
2. **Filter Results** - Use the sidebar filters to narrow down choices
3. **Add to Cart** - Click "Add to Cart" on any product
4. **Manage Cart** - View cart, adjust quantities, apply discount codes
5. **Checkout** - Complete purchase with secure payment
6. **Track Orders** - View order history and status in your account

### For Developers
1. **API Endpoints** - All backend functionality exposed via REST API
2. **Database Schema** - Mongoose models for products, users, and orders
3. **Authentication** - JWT-based user authentication system
4. **Responsive Design** - Mobile-first approach with Tailwind CSS

## 🔧 Configuration

### Environment Variables
- `MONGODB_URI` - MongoDB connection string
- `JWT_SECRET` - Secret key for JWT tokens
- `PORT` - Server port (default: 3000)

### Customization
- **Brands** - Add new brands in the `main.js` file
- **Categories** - Modify product categories in the database
- **Styling** - Update CSS custom properties in each HTML file
- **Animations** - Adjust animation settings in JavaScript

## 🎨 Design System

The project follows a consistent design system:
- **Colors**: Primary (#2C3E50), Secondary (#7F8C8D), Accent (#FF6B6B)
- **Typography**: Playfair Display (headings), Inter (body text)
- **Spacing**: 4px base unit system
- **Components**: Reusable card, button, and form styles

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🔒 Security Features

- Password hashing with bcrypt
- JWT token authentication
- Input validation and sanitization
- CORS protection
- Secure session management

## 📊 Performance Optimizations

- Lazy loading for images
- Efficient database queries
- Minimal JavaScript bundle
- Optimized CSS delivery
- Compression support

## 🌐 Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support or questions:
- Create an issue in the repository
- Check the documentation files
- Review the code comments

## 🙏 Acknowledgments

- Images from Unsplash
- Icons from Font Awesome
- Animations from Anime.js
- Carousels from Splide.js
- Typography from Google Fonts

---

**Happy Shopping! 🛒**